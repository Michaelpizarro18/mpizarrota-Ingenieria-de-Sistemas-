package Vista_SalesSystem;

import DataBase_SalesSystem.Conexion;
import Modelo_SalesSystem.DetalleVenta;
import java.awt.Color;
import java.awt.Image;
import java.awt.List;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

public class V_Sistema extends javax.swing.JFrame {

    Connection con = Conexion.getConexion();
    public DefaultTableModel modelito;
    
    

    public V_Sistema() throws SQLException {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        PonerDatosCBX();
        PonerProveedores();
        this.Colocar("DulcesPaula.jpg", lblLogo);
        this.Colocar("casa.png", lblCasita);
        this.Colocar("caja-registradora.png", lblRegistro);
        this.Colocar("gestion-de-la-cadena-de-suministro.png", lblProveedor);
        this.Colocar("productos-cosmeticos.png", lblProductos);
        this.Colocar("cerrar-sesion.png", lblSalida);
        Correspondiente();
        this.DesactivarCajas();
        //this.CalculoInmediato();
        txtCantidad.getDocument().addDocumentListener(new MyDocumentListener());
        txtPrecio.getDocument().addDocumentListener(new MyDocumentListener());
        txtDescuento.getDocument().addDocumentListener(new MyDocumentListener());

        //TABLA
        modelito = new DefaultTableModel();
        modelito.addColumn("PRODUCTO");
        modelito.addColumn("CANTIDAD");
        modelito.addColumn("PRECIO");
        modelito.addColumn("DESCUENTO");
        modelito.addColumn("SUBTOTAL");
        modelito.addColumn("IMPUESTO");
        modelito.addColumn("TOTAL");

        tblDatos.setModel(modelito);
    }

    public void Colocar(String path, JLabel label) {
        File ruta = new File("src/main/java/Imagenes/" + path);

        if (ruta.exists()) {
            ImageIcon icono = new ImageIcon(ruta.getAbsolutePath());
            Image imagen = icono.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_DEFAULT);

            label.setIcon(new ImageIcon(imagen));

        } else {
            JOptionPane.showMessageDialog(null, "No se pudo encontrar la imagen");
        }
    }

    public void Correspondiente() {
        this.Colocar("Pastelito.png", lblPastelito1);
        this.Colocar("Pastelito1.png", lblPastelito2);
        this.Colocar("Pastelito3.png", lblPastelito3);
        this.Colocar("Empana.png", lblPastelito4);
        this.Colocar("Alfajor.png", lblPastelito5);
        this.Colocar("Alfajor (1).png", lblPastelito6);
        this.Colocar("Pastelito1.png", lblPastelito7);
        this.Colocar("Pastelito3.png", lblPastelito8);
        this.Colocar("Empana.png", lblPastelito9);
        this.Colocar("Alfajor.png", lblPastelito10);
    }

    public void PonerDatosCBX() throws SQLException {
        String consultaSql = "SELECT nombre FROM Producto";

        Connection con = Conexion.getConexion();
        try (PreparedStatement statement = con.prepareStatement(consultaSql)) {
            ResultSet resultSet = statement.executeQuery();

            // Agrega los nombres de los productos al ComboBox
            while (resultSet.next()) {
                String nombreProducto = resultSet.getString("nombre");
                cbxProducto.addItem(nombreProducto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void PonerProveedores() throws SQLException {
        String consultaSql = "SELECT pronombre FROM Proveedor";

        Connection con = Conexion.getConexion();
        try (PreparedStatement statement = con.prepareStatement(consultaSql)) {
            ResultSet resultSet = statement.executeQuery();

            // Agrega los nombres de los productos al ComboBox
            while (resultSet.next()) {
                String nombreProveedor = resultSet.getString("pronombre");
                cbxProveedor.addItem(nombreProveedor);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void DesactivarCajas() {
        txtIDCompra.setEnabled(false);
        txtIDProveedor.setEnabled(false);
        txtIDProducto.setEnabled(false);
        txtPrecio.setEnabled(false);
        txtSubtotal.setEnabled(false);
        txtTotal.setEnabled(false);
        txtTotalFinal.setEnabled(false);
        txtImpuesto.setEnabled(false);
    }

    public class MyDocumentListener implements DocumentListener {

        @Override
        public void insertUpdate(DocumentEvent e) {
            calcularResultado();
        }

        @Override
        public void removeUpdate(DocumentEvent e) {
            calcularResultado();
        }

        @Override
        public void changedUpdate(DocumentEvent e) {
            calcularResultado();
        }

        private void calcularResultado() {
            try {
                int num1 = (txtCantidad.getText().isEmpty()) ? 1 : Integer.parseInt(txtCantidad.getText());
                double num2 = (txtPrecio.getText().isEmpty()) ? 1 : Double.parseDouble(txtPrecio.getText());
                double num3 = (txtDescuento.getText().isEmpty() || txtDescuento.getText().equals("0")) ? 1 : Double.parseDouble(txtDescuento.getText());

                double resultado = num1 * num2 * num3;
                txtSubtotal.setText(String.valueOf(resultado));
                txtTotal.setText(String.valueOf(resultado));
            } catch (NumberFormatException ex) {
                txtSubtotal.setText("Error");
                txtTotal.setText("Error");
            }
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelFondoMenu = new javax.swing.JPanel();
        TCambiador = new javax.swing.JTabbedPane();
        PanelInicio = new javax.swing.JPanel();
        PanelSubInicio = new javax.swing.JPanel();
        PanelBanner = new javax.swing.JPanel();
        lblPastelito1 = new javax.swing.JLabel();
        lblPastelito2 = new javax.swing.JLabel();
        lblPastelito3 = new javax.swing.JLabel();
        lblPastelito4 = new javax.swing.JLabel();
        lblPastelito5 = new javax.swing.JLabel();
        lblPastelito6 = new javax.swing.JLabel();
        lblPastelito7 = new javax.swing.JLabel();
        lblPastelito8 = new javax.swing.JLabel();
        lblPastelito9 = new javax.swing.JLabel();
        lblPastelito10 = new javax.swing.JLabel();
        lblTituloEntrada = new javax.swing.JLabel();
        PanelDelMensaje = new javax.swing.JPanel();
        lblLinea5 = new javax.swing.JLabel();
        lblLinea1 = new javax.swing.JLabel();
        lblLinea2 = new javax.swing.JLabel();
        lblLinea3 = new javax.swing.JLabel();
        lblLinea4 = new javax.swing.JLabel();
        PanelDeVentas = new javax.swing.JPanel();
        PanelFondo = new javax.swing.JPanel();
        PanelUp = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        btnGuardar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        txtIDCompra = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtIDProveedor = new javax.swing.JTextField();
        txtIDProducto = new javax.swing.JTextField();
        cbxProducto = new javax.swing.JComboBox<>();
        txtFecha = new javax.swing.JTextField();
        cbxProveedor = new javax.swing.JComboBox<>();
        txtFactura = new javax.swing.JTextField();
        txtCantidad = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        txtDescuento = new javax.swing.JTextField();
        txtSubtotal = new javax.swing.JTextField();
        txtImpuesto = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JTextField();
        btnAgregarATabla = new javax.swing.JButton();
        PanelDown = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblDatos = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        txtTotalFinal = new javax.swing.JTextField();
        btnQuitarDeTabla = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        PanelLateralDerecho = new javax.swing.JPanel();
        PanelSesion = new javax.swing.JPanel();
        lblSalida = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblLogo = new javax.swing.JLabel();
        PanelDPrincipal = new javax.swing.JPanel();
        lblPTexto = new javax.swing.JLabel();
        lblCasita = new javax.swing.JLabel();
        PanelDVenta = new javax.swing.JPanel();
        lblV = new javax.swing.JLabel();
        lblR = new javax.swing.JLabel();
        lblRegistro = new javax.swing.JLabel();
        PanelDProveedor = new javax.swing.JPanel();
        lblPro = new javax.swing.JLabel();
        lblProveedor = new javax.swing.JLabel();
        PanelDProductos = new javax.swing.JPanel();
        lblPr = new javax.swing.JLabel();
        lblProductos = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelFondoMenu.setBackground(new java.awt.Color(204, 204, 204));
        PanelFondoMenu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TCambiador.setBackground(new java.awt.Color(0, 0, 0));

        PanelInicio.setBackground(new java.awt.Color(204, 255, 255));
        PanelInicio.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelSubInicio.setBackground(new java.awt.Color(255, 255, 255));
        PanelSubInicio.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelBanner.setBackground(new java.awt.Color(255, 165, 227));
        PanelBanner.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblPastelito1.setText("Imagen");
        PanelBanner.add(lblPastelito1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 70, 70));

        lblPastelito2.setText("Imagen");
        PanelBanner.add(lblPastelito2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, 70, 70));

        lblPastelito3.setText("Imagen");
        PanelBanner.add(lblPastelito3, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 20, 70, 70));

        lblPastelito4.setText("Imagen");
        PanelBanner.add(lblPastelito4, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 70, 70));

        lblPastelito5.setText("Imagen");
        PanelBanner.add(lblPastelito5, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, 70, 70));

        lblPastelito6.setText("Imagen");
        PanelBanner.add(lblPastelito6, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, 70, 70));

        lblPastelito7.setText("Imagen");
        PanelBanner.add(lblPastelito7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 20, 70, 70));

        lblPastelito8.setText("Imagen");
        PanelBanner.add(lblPastelito8, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 10, 70, 70));

        lblPastelito9.setText("Imagen");
        PanelBanner.add(lblPastelito9, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 20, 70, 70));

        lblPastelito10.setText("Imagen");
        PanelBanner.add(lblPastelito10, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 10, 70, 70));

        PanelSubInicio.add(PanelBanner, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 100));

        lblTituloEntrada.setFont(new java.awt.Font("Noto Sans", 1, 30)); // NOI18N
        lblTituloEntrada.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTituloEntrada.setText("¡Bienvenido al sistema, Jefe!");
        PanelSubInicio.add(lblTituloEntrada, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 200, 430, 60));

        PanelDelMensaje.setBackground(new java.awt.Color(255, 255, 255));
        PanelDelMensaje.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        PanelDelMensaje.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblLinea5.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblLinea5.setText("negocio de repostería de manera eficienta y deliciosa!");
        PanelDelMensaje.add(lblLinea5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 550, 20));

        lblLinea1.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblLinea1.setText("Estamos encantados de que estes aquí. Desde esta plataforma, puedes");
        PanelDelMensaje.add(lblLinea1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 550, 20));

        lblLinea2.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblLinea2.setText("supervisar y gestionar todos los aspectos de nuestra repostería. Si tienes");
        PanelDelMensaje.add(lblLinea2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 560, 20));

        lblLinea3.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblLinea3.setText("alguna solicitud especial o necesitas asistencia, estamos a tu");
        PanelDelMensaje.add(lblLinea3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 550, 20));

        lblLinea4.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblLinea4.setText("disposición. ¡Gracias por confiar en nosotros para llevar a cabo tu");
        PanelDelMensaje.add(lblLinea4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 540, -1));

        PanelSubInicio.add(PanelDelMensaje, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 270, 600, 130));

        PanelInicio.add(PanelSubInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 720));

        TCambiador.addTab("tab1", PanelInicio);

        PanelDeVentas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelFondo.setBackground(new java.awt.Color(204, 204, 204));
        PanelFondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelUp.setBackground(new java.awt.Color(153, 0, 255));
        PanelUp.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 30)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("REGISTRO DE COMPRAS");
        PanelUp.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 20, -1, -1));

        PanelFondo.add(PanelUp, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 80));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        jPanel4.add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 70, 40));

        btnBuscar.setText("Buscar");
        jPanel4.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, 70, 40));

        btnEliminar.setText("Eliminar");
        jPanel4.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 40));

        btnLimpiar.setText("Limpiar");
        jPanel4.add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, 70, 40));

        txtIDCompra.setForeground(new java.awt.Color(0, 0, 0));
        txtIDCompra.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtIDCompra.setText("1");
        txtIDCompra.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.add(txtIDCompra, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 30, 80, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("ID COMPRA:");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 10, -1, -1));

        PanelFondo.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 980, 80));

        jPanel1.setBackground(new java.awt.Color(153, 102, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Proveedor:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 20, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Total:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 110, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Factura:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("IDProveedor:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 20, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Cod. Producto:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Producto:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Cantidad:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 110, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("Precio:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 110, -1, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Descuento:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 110, -1, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 0));
        jLabel13.setText("Subtotal:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 110, -1, -1));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("Impuesto:");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 110, -1, -1));

        txtIDProveedor.setForeground(new java.awt.Color(0, 0, 0));
        txtIDProveedor.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtIDProveedor.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(txtIDProveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 50, 110, 40));

        txtIDProducto.setForeground(new java.awt.Color(0, 0, 0));
        txtIDProducto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtIDProducto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(txtIDProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 100, 40));

        cbxProducto.setForeground(new java.awt.Color(0, 0, 0));
        cbxProducto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Seleccionar--" }));
        cbxProducto.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxProductoItemStateChanged(evt);
            }
        });
        jPanel1.add(cbxProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 160, 40));

        txtFecha.setForeground(new java.awt.Color(0, 0, 0));
        txtFecha.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 70, 40));

        cbxProveedor.setForeground(new java.awt.Color(0, 0, 0));
        cbxProveedor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Seleccionar--" }));
        cbxProveedor.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxProveedorItemStateChanged(evt);
            }
        });
        jPanel1.add(cbxProveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 50, 290, 40));

        txtFactura.setForeground(new java.awt.Color(0, 0, 0));
        txtFactura.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFactura.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(txtFactura, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 70, 40));

        txtCantidad.setForeground(new java.awt.Color(0, 0, 0));
        txtCantidad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCantidad.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txtCantidad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtCantidadMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                txtCantidadMouseReleased(evt);
            }
        });
        jPanel1.add(txtCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 140, 80, 40));

        txtPrecio.setForeground(new java.awt.Color(0, 0, 0));
        txtPrecio.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtPrecio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(txtPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 140, 80, 40));

        txtDescuento.setForeground(new java.awt.Color(0, 0, 0));
        txtDescuento.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtDescuento.setText("0");
        txtDescuento.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txtDescuento.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDescuentoMousePressed(evt);
            }
        });
        jPanel1.add(txtDescuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 140, 80, 40));

        txtSubtotal.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtSubtotal.setForeground(new java.awt.Color(0, 0, 0));
        txtSubtotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSubtotal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(txtSubtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 140, 80, 40));

        txtImpuesto.setForeground(new java.awt.Color(0, 0, 0));
        txtImpuesto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtImpuesto.setText("0");
        txtImpuesto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(txtImpuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 140, 80, 40));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 0));
        jLabel15.setText("Fecha:");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        txtTotal.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtTotal.setForeground(new java.awt.Color(0, 0, 0));
        txtTotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTotal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 140, 80, 40));

        btnAgregarATabla.setText("+");
        btnAgregarATabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarATablaActionPerformed(evt);
            }
        });
        jPanel1.add(btnAgregarATabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 140, 50, 40));

        PanelFondo.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 980, 200));

        PanelDown.setBackground(new java.awt.Color(255, 204, 255));
        PanelDown.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PRODUCTO", "CANTIDAD", "PRECIO", "DESCUENTO", "SUBTOTAL", "IMPUESTO", "TOTAL"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblDatos);

        PanelDown.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 890, 250));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setText("TOTAL");
        PanelDown.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 300, -1, -1));

        txtTotalFinal.setForeground(new java.awt.Color(0, 0, 0));
        txtTotalFinal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTotalFinal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        PanelDown.add(txtTotalFinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 290, 80, 40));

        btnQuitarDeTabla.setText("-");
        btnQuitarDeTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQuitarDeTablaActionPerformed(evt);
            }
        });
        PanelDown.add(btnQuitarDeTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 60, 50, 40));

        PanelFondo.add(PanelDown, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 360, 980, 350));

        PanelDeVentas.add(PanelFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 710));

        TCambiador.addTab("tab2", PanelDeVentas);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 975, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 710, Short.MAX_VALUE)
        );

        TCambiador.addTab("tab3", jPanel2);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 975, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 710, Short.MAX_VALUE)
        );

        TCambiador.addTab("tab4", jPanel3);

        PanelFondoMenu.add(TCambiador, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, -30, 980, 740));

        PanelLateralDerecho.setBackground(new java.awt.Color(255, 255, 255));
        PanelLateralDerecho.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelSesion.setBackground(new java.awt.Color(255, 255, 255));
        PanelSesion.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        PanelSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PanelSesionMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PanelSesionMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PanelSesionMouseExited(evt);
            }
        });
        PanelSesion.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblSalida.setForeground(new java.awt.Color(255, 255, 255));
        lblSalida.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblSalidaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblSalidaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblSalidaMouseExited(evt);
            }
        });
        PanelSesion.add(lblSalida, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 45, 50));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Cerrar Sesión");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel2MouseExited(evt);
            }
        });
        PanelSesion.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, -1, 30));

        PanelLateralDerecho.add(PanelSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 590, 190, 70));

        lblLogo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        PanelLateralDerecho.add(lblLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 90, 90));

        PanelDPrincipal.setBackground(new java.awt.Color(0, 0, 0));
        PanelDPrincipal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        PanelDPrincipal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PanelDPrincipalMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PanelDPrincipalMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PanelDPrincipalMouseExited(evt);
            }
        });
        PanelDPrincipal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblPTexto.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        lblPTexto.setForeground(new java.awt.Color(255, 255, 255));
        lblPTexto.setText("Principal");
        lblPTexto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPTextoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblPTextoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblPTextoMouseExited(evt);
            }
        });
        PanelDPrincipal.add(lblPTexto, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, -1, 20));

        lblCasita.setForeground(new java.awt.Color(255, 255, 255));
        lblCasita.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCasitaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblCasitaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblCasitaMouseExited(evt);
            }
        });
        PanelDPrincipal.add(lblCasita, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 40, 40));

        PanelLateralDerecho.add(PanelDPrincipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 190, 60));

        PanelDVenta.setBackground(new java.awt.Color(255, 255, 255));
        PanelDVenta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        PanelDVenta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PanelDVentaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PanelDVentaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PanelDVentaMouseExited(evt);
            }
        });
        PanelDVenta.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblV.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        lblV.setForeground(new java.awt.Color(0, 0, 0));
        lblV.setText("Venta");
        lblV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblVMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblVMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblVMouseExited(evt);
            }
        });
        PanelDVenta.add(lblV, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 30, -1, 20));

        lblR.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        lblR.setForeground(new java.awt.Color(0, 0, 0));
        lblR.setText("Registrar");
        lblR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblRMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblRMouseExited(evt);
            }
        });
        PanelDVenta.add(lblR, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, -1, 20));

        lblRegistro.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRegistroMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblRegistroMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblRegistroMouseExited(evt);
            }
        });
        PanelDVenta.add(lblRegistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 50, 40));

        PanelLateralDerecho.add(PanelDVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 190, 60));

        PanelDProveedor.setBackground(new java.awt.Color(255, 255, 255));
        PanelDProveedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        PanelDProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PanelDProveedorMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PanelDProveedorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PanelDProveedorMouseExited(evt);
            }
        });
        PanelDProveedor.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblPro.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        lblPro.setForeground(new java.awt.Color(0, 0, 0));
        lblPro.setText("Proveedor");
        lblPro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblProMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblProMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblProMouseExited(evt);
            }
        });
        PanelDProveedor.add(lblPro, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, -1, 20));

        lblProveedor.setForeground(new java.awt.Color(255, 255, 255));
        lblProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblProveedorMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblProveedorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblProveedorMouseExited(evt);
            }
        });
        PanelDProveedor.add(lblProveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 50, 40));

        PanelLateralDerecho.add(PanelDProveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 190, 60));

        PanelDProductos.setBackground(new java.awt.Color(255, 255, 255));
        PanelDProductos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        PanelDProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PanelDProductosMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PanelDProductosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PanelDProductosMouseExited(evt);
            }
        });
        PanelDProductos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblPr.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        lblPr.setForeground(new java.awt.Color(0, 0, 0));
        lblPr.setText("Productos");
        lblPr.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPrMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblPrMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblPrMouseExited(evt);
            }
        });
        PanelDProductos.add(lblPr, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, -1, 20));

        lblProductos.setForeground(new java.awt.Color(255, 255, 255));
        lblProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblProductosMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblProductosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblProductosMouseExited(evt);
            }
        });
        PanelDProductos.add(lblProductos, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 50, 40));

        PanelLateralDerecho.add(PanelDProductos, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 360, 190, 60));

        PanelFondoMenu.add(PanelLateralDerecho, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 190, 710));

        getContentPane().add(PanelFondoMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1170, 710));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PanelDVentaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDVentaMouseEntered
        if (PanelDVenta.getBackground().equals(new Color(255, 255, 255))) {
            PanelDVenta.setBackground(new Color(211, 211, 211));
        }

    }//GEN-LAST:event_PanelDVentaMouseEntered

    private void lblRegistroMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegistroMouseEntered
        if (PanelDVenta.getBackground().equals(new Color(255, 255, 255))) {
            PanelDVenta.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_lblRegistroMouseEntered

    private void lblRMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRMouseEntered
        if (PanelDVenta.getBackground().equals(new Color(255, 255, 255))) {
            PanelDVenta.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_lblRMouseEntered

    private void lblVMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblVMouseEntered
        if (PanelDVenta.getBackground().equals(new Color(255, 255, 255))) {
            PanelDVenta.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_lblVMouseEntered

    private void PanelDVentaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDVentaMouseExited
        if (PanelDVenta.getBackground().equals(new Color(211, 211, 211))) {
            PanelDVenta.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_PanelDVentaMouseExited

    private void lblRegistroMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegistroMouseExited
        if (PanelDVenta.getBackground().equals(new Color(211, 211, 211))) {
            PanelDVenta.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_lblRegistroMouseExited

    private void lblRMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRMouseExited
        if (PanelDVenta.getBackground().equals(new Color(211, 211, 211))) {
            PanelDVenta.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_lblRMouseExited

    private void lblVMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblVMouseExited
        if (PanelDVenta.getBackground().equals(new Color(211, 211, 211))) {
            PanelDVenta.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_lblVMouseExited

    private void PanelDProveedorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDProveedorMouseEntered
        if (PanelDProveedor.getBackground().equals(new Color(255, 255, 255))) {
            PanelDProveedor.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_PanelDProveedorMouseEntered

    private void lblProMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProMouseEntered
        if (PanelDProveedor.getBackground().equals(new Color(255, 255, 255))) {
            PanelDProveedor.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_lblProMouseEntered

    private void lblProveedorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProveedorMouseEntered
        if (PanelDProveedor.getBackground().equals(new Color(255, 255, 255))) {
            PanelDProveedor.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_lblProveedorMouseEntered

    private void PanelDProveedorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDProveedorMouseExited
        if (PanelDProveedor.getBackground().equals(new Color(211, 211, 211))) {
            PanelDProveedor.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_PanelDProveedorMouseExited

    private void lblProMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProMouseExited
        if (PanelDProveedor.getBackground().equals(new Color(211, 211, 211))) {
            PanelDProveedor.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_lblProMouseExited

    private void lblProveedorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProveedorMouseExited
        if (PanelDProveedor.getBackground().equals(new Color(211, 211, 211))) {
            PanelDProveedor.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_lblProveedorMouseExited

    private void PanelDProductosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDProductosMouseEntered
        if (PanelDProductos.getBackground().equals(new Color(255, 255, 255))) {
            PanelDProductos.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_PanelDProductosMouseEntered

    private void lblPrMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPrMouseEntered
        if (PanelDProductos.getBackground().equals(new Color(255, 255, 255))) {
            PanelDProductos.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_lblPrMouseEntered

    private void lblProductosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProductosMouseEntered
        if (PanelDProductos.getBackground().equals(new Color(255, 255, 255))) {
            PanelDProductos.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_lblProductosMouseEntered

    private void PanelDProductosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDProductosMouseExited
        if (PanelDProductos.getBackground().equals(new Color(211, 211, 211))) {
            PanelDProductos.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_PanelDProductosMouseExited

    private void lblPrMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPrMouseExited
        if (PanelDProductos.getBackground().equals(new Color(211, 211, 211))) {
            PanelDProductos.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_lblPrMouseExited

    private void lblProductosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProductosMouseExited
        if (PanelDProductos.getBackground().equals(new Color(211, 211, 211))) {
            PanelDProductos.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_lblProductosMouseExited

    private void PanelSesionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelSesionMouseEntered
        if (PanelSesion.getBackground().equals(new Color(255, 255, 255))) {
            PanelSesion.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_PanelSesionMouseEntered

    private void jLabel2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseEntered
        if (PanelSesion.getBackground().equals(new Color(255, 255, 255))) {
            PanelSesion.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_jLabel2MouseEntered

    private void lblSalidaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSalidaMouseEntered
        if (PanelSesion.getBackground().equals(new Color(255, 255, 255))) {
            PanelSesion.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_lblSalidaMouseEntered

    private void PanelSesionMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelSesionMouseExited
        if (PanelSesion.getBackground().equals(new Color(211, 211, 211))) {
            PanelSesion.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_PanelSesionMouseExited

    private void jLabel2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseExited
        if (PanelSesion.getBackground().equals(new Color(211, 211, 211))) {
            PanelSesion.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_jLabel2MouseExited

    private void lblSalidaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSalidaMouseExited
        if (PanelSesion.getBackground().equals(new Color(211, 211, 211))) {
            PanelSesion.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_lblSalidaMouseExited

    private void PanelDPrincipalMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDPrincipalMouseEntered
        if (PanelDPrincipal.getBackground().equals(new Color(255, 255, 255))) {
            PanelDPrincipal.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_PanelDPrincipalMouseEntered

    private void lblPTextoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPTextoMouseEntered
        if (PanelDPrincipal.getBackground().equals(new Color(255, 255, 255))) {
            PanelDPrincipal.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_lblPTextoMouseEntered

    private void lblCasitaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCasitaMouseEntered
        if (PanelDPrincipal.getBackground().equals(new Color(255, 255, 255))) {
            PanelDPrincipal.setBackground(new Color(211, 211, 211));
        }
    }//GEN-LAST:event_lblCasitaMouseEntered

    private void PanelDPrincipalMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDPrincipalMouseExited
        if (PanelDPrincipal.getBackground().equals(new Color(211, 211, 211))) {
            PanelDPrincipal.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_PanelDPrincipalMouseExited

    private void lblPTextoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPTextoMouseExited
        if (PanelDPrincipal.getBackground().equals(new Color(211, 211, 211))) {
            PanelDPrincipal.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_lblPTextoMouseExited

    private void lblCasitaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCasitaMouseExited
        if (PanelDPrincipal.getBackground().equals(new Color(211, 211, 211))) {
            PanelDPrincipal.setBackground(new Color(255, 255, 255));
        }
    }//GEN-LAST:event_lblCasitaMouseExited

    private void PanelDPrincipalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDPrincipalMouseClicked
        TCambiador.setSelectedIndex(0);
        PanelDPrincipal.setBackground(new Color(0, 0, 0));
        lblPTexto.setForeground(new Color(255, 255, 255));
        this.Colocar("casa.png", lblCasita);

        //Los demás
        //REGISTRO DE VENTA
        PanelDVenta.setBackground(new Color(255, 255, 255));
        lblR.setForeground(new Color(0, 0, 0));
        lblV.setForeground(new Color(0, 0, 0));
        this.Colocar("caja-registradora.png", lblRegistro);

        //PROVEEDOR
        PanelDProveedor.setBackground(new Color(255, 255, 255));
        lblPro.setForeground(new Color(0, 0, 0));
        this.Colocar("gestion-de-la-cadena-de-suministro.png", lblProveedor);

        //PRODUCTOS
        PanelDProductos.setBackground(new Color(255, 255, 255));
        lblPr.setForeground(new Color(0, 0, 0));
        this.Colocar("productos-cosmeticos.png", lblProductos);
    }//GEN-LAST:event_PanelDPrincipalMouseClicked

    private void lblPTextoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPTextoMouseClicked
        TCambiador.setSelectedIndex(0);
        PanelDPrincipal.setBackground(new Color(0, 0, 0));
        lblPTexto.setForeground(new Color(255, 255, 255));
        this.Colocar("casa.png", lblCasita);

        //Los demás
        //REGISTRO DE VENTA
        PanelDVenta.setBackground(new Color(255, 255, 255));
        lblR.setForeground(new Color(0, 0, 0));
        lblV.setForeground(new Color(0, 0, 0));
        this.Colocar("caja-registradora.png", lblRegistro);

        //PROVEEDOR
        PanelDProveedor.setBackground(new Color(255, 255, 255));
        lblPro.setForeground(new Color(0, 0, 0));
        this.Colocar("gestion-de-la-cadena-de-suministro.png", lblProveedor);

        //PRODUCTOS
        PanelDProductos.setBackground(new Color(255, 255, 255));
        lblPr.setForeground(new Color(0, 0, 0));
        this.Colocar("productos-cosmeticos.png", lblProductos);
    }//GEN-LAST:event_lblPTextoMouseClicked

    private void lblCasitaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCasitaMouseClicked
        TCambiador.setSelectedIndex(0);
        PanelDPrincipal.setBackground(new Color(0, 0, 0));
        lblPTexto.setForeground(new Color(255, 255, 255));
        this.Colocar("casa.png", lblCasita);

        //Los demás
        //REGISTRO DE VENTA
        PanelDVenta.setBackground(new Color(255, 255, 255));
        lblR.setForeground(new Color(0, 0, 0));
        lblV.setForeground(new Color(0, 0, 0));
        this.Colocar("caja-registradora.png", lblRegistro);

        //PROVEEDOR
        PanelDProveedor.setBackground(new Color(255, 255, 255));
        lblPro.setForeground(new Color(0, 0, 0));
        this.Colocar("gestion-de-la-cadena-de-suministro.png", lblProveedor);

        //PRODUCTOS
        PanelDProductos.setBackground(new Color(255, 255, 255));
        lblPr.setForeground(new Color(0, 0, 0));
        this.Colocar("productos-cosmeticos.png", lblProductos);
    }//GEN-LAST:event_lblCasitaMouseClicked

    private void PanelDVentaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDVentaMouseClicked
        TCambiador.setSelectedIndex(1);
        PanelDVenta.setBackground(new Color(0, 0, 0));
        lblR.setForeground(new Color(255, 255, 255));
        lblV.setForeground(new Color(255, 255, 255));
        this.Colocar("caja-registradora (1).png", lblRegistro);

        //Lo demás
        //PRINCIPAL
        PanelDPrincipal.setBackground(new Color(255, 255, 255));
        lblPTexto.setForeground(new Color(0, 0, 0));
        this.Colocar("casa-silueta-negra-sin-puerta.png", lblCasita);

        //PROVEEDOR
        PanelDProveedor.setBackground(new Color(255, 255, 255));
        lblPro.setForeground(new Color(0, 0, 0));
        this.Colocar("gestion-de-la-cadena-de-suministro.png", lblProveedor);

        //PRODUCTOS
        PanelDProductos.setBackground(new Color(255, 255, 255));
        lblPr.setForeground(new Color(0, 0, 0));
        this.Colocar("productos-cosmeticos.png", lblProductos);
    }//GEN-LAST:event_PanelDVentaMouseClicked

    private void lblRMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRMouseClicked
        TCambiador.setSelectedIndex(1);
        PanelDVenta.setBackground(new Color(0, 0, 0));
        lblR.setForeground(new Color(255, 255, 255));
        lblV.setForeground(new Color(255, 255, 255));
        this.Colocar("caja-registradora (1).png", lblRegistro);

        //Lo demás
        //PRINCIPAL
        PanelDPrincipal.setBackground(new Color(255, 255, 255));
        lblPTexto.setForeground(new Color(0, 0, 0));
        this.Colocar("casa-silueta-negra-sin-puerta.png", lblCasita);

        //PROVEEDOR
        PanelDProveedor.setBackground(new Color(255, 255, 255));
        lblPro.setForeground(new Color(0, 0, 0));
        this.Colocar("gestion-de-la-cadena-de-suministro.png", lblProveedor);

        //PRODUCTOS
        PanelDProductos.setBackground(new Color(255, 255, 255));
        lblPr.setForeground(new Color(0, 0, 0));
        this.Colocar("productos-cosmeticos.png", lblProductos);
    }//GEN-LAST:event_lblRMouseClicked

    private void lblVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblVMouseClicked
        TCambiador.setSelectedIndex(1);
        PanelDVenta.setBackground(new Color(0, 0, 0));
        lblR.setForeground(new Color(255, 255, 255));
        lblV.setForeground(new Color(255, 255, 255));
        this.Colocar("caja-registradora (1).png", lblRegistro);

        //Lo demás
        //PRINCIPAL
        PanelDPrincipal.setBackground(new Color(255, 255, 255));
        lblPTexto.setForeground(new Color(0, 0, 0));
        this.Colocar("casa-silueta-negra-sin-puerta.png", lblCasita);

        //PROVEEDOR
        PanelDProveedor.setBackground(new Color(255, 255, 255));
        lblPro.setForeground(new Color(0, 0, 0));
        this.Colocar("gestion-de-la-cadena-de-suministro.png", lblProveedor);

        //PRODUCTOS
        PanelDProductos.setBackground(new Color(255, 255, 255));
        lblPr.setForeground(new Color(0, 0, 0));
        this.Colocar("productos-cosmeticos.png", lblProductos);
    }//GEN-LAST:event_lblVMouseClicked

    private void lblRegistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegistroMouseClicked
        TCambiador.setSelectedIndex(1);
        PanelDVenta.setBackground(new Color(0, 0, 0));
        lblR.setForeground(new Color(255, 255, 255));
        lblV.setForeground(new Color(255, 255, 255));
        this.Colocar("caja-registradora (1).png", lblRegistro);

        //Lo demás
        //PRINCIPAL
        PanelDPrincipal.setBackground(new Color(255, 255, 255));
        lblPTexto.setForeground(new Color(0, 0, 0));
        this.Colocar("casa-silueta-negra-sin-puerta.png", lblCasita);

        //PROVEEDOR
        PanelDProveedor.setBackground(new Color(255, 255, 255));
        lblPro.setForeground(new Color(0, 0, 0));
        this.Colocar("gestion-de-la-cadena-de-suministro.png", lblProveedor);

        //PRODUCTOS
        PanelDProductos.setBackground(new Color(255, 255, 255));
        lblPr.setForeground(new Color(0, 0, 0));
        this.Colocar("productos-cosmeticos.png", lblProductos);
    }//GEN-LAST:event_lblRegistroMouseClicked

    private void PanelDProveedorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDProveedorMouseClicked
        TCambiador.setSelectedIndex(2);
        PanelDProveedor.setBackground(new Color(0, 0, 0));
        lblPro.setForeground(new Color(255, 255, 255));
        this.Colocar("gestion-de-la-cadena-de-suministro (2).png", lblProveedor);

        //Lo demás
        //PRINCIPAL
        PanelDPrincipal.setBackground(new Color(255, 255, 255));
        lblPTexto.setForeground(new Color(0, 0, 0));
        this.Colocar("casa-silueta-negra-sin-puerta.png", lblCasita);

        //REGISTRO DE VENTAS
        PanelDVenta.setBackground(new Color(255, 255, 255));
        lblR.setForeground(new Color(0, 0, 0));
        lblV.setForeground(new Color(0, 0, 0));
        this.Colocar("caja-registradora.png", lblRegistro);

        //PRODUCTOS
        PanelDProductos.setBackground(new Color(255, 255, 255));
        lblPr.setForeground(new Color(0, 0, 0));
        this.Colocar("productos-cosmeticos.png", lblProductos);
    }//GEN-LAST:event_PanelDProveedorMouseClicked

    private void lblProMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProMouseClicked
        TCambiador.setSelectedIndex(2);
        PanelDProveedor.setBackground(new Color(0, 0, 0));
        lblPro.setForeground(new Color(255, 255, 255));
        this.Colocar("gestion-de-la-cadena-de-suministro (2).png", lblProveedor);

        //Lo demás
        //PRINCIPAL
        PanelDPrincipal.setBackground(new Color(255, 255, 255));
        lblPTexto.setForeground(new Color(0, 0, 0));
        this.Colocar("casa-silueta-negra-sin-puerta.png", lblCasita);

        //REGISTRO DE VENTAS
        PanelDVenta.setBackground(new Color(255, 255, 255));
        lblR.setForeground(new Color(0, 0, 0));
        lblV.setForeground(new Color(0, 0, 0));
        this.Colocar("caja-registradora.png", lblRegistro);

        //PRODUCTOS
        PanelDProductos.setBackground(new Color(255, 255, 255));
        lblPr.setForeground(new Color(0, 0, 0));
        this.Colocar("productos-cosmeticos.png", lblProductos);
    }//GEN-LAST:event_lblProMouseClicked

    private void lblProveedorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProveedorMouseClicked
        TCambiador.setSelectedIndex(2);
        PanelDProveedor.setBackground(new Color(0, 0, 0));
        lblPro.setForeground(new Color(255, 255, 255));
        this.Colocar("gestion-de-la-cadena-de-suministro (2).png", lblProveedor);

        //Lo demás
        //PRINCIPAL
        PanelDPrincipal.setBackground(new Color(255, 255, 255));
        lblPTexto.setForeground(new Color(0, 0, 0));
        this.Colocar("casa-silueta-negra-sin-puerta.png", lblCasita);

        //REGISTRO DE VENTAS
        PanelDVenta.setBackground(new Color(255, 255, 255));
        lblR.setForeground(new Color(0, 0, 0));
        lblV.setForeground(new Color(0, 0, 0));
        this.Colocar("caja-registradora.png", lblRegistro);

        //PRODUCTOS
        PanelDProductos.setBackground(new Color(255, 255, 255));
        lblPr.setForeground(new Color(0, 0, 0));
        this.Colocar("productos-cosmeticos.png", lblProductos);
    }//GEN-LAST:event_lblProveedorMouseClicked

    private void PanelDProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelDProductosMouseClicked
        TCambiador.setSelectedIndex(3);
        PanelDProductos.setBackground(new Color(0, 0, 0));
        lblPr.setForeground(new Color(255, 255, 255));
        this.Colocar("productos-cosmeticos (1).png", lblProductos);

        //Lo demás
        //PRINCIPAL
        PanelDPrincipal.setBackground(new Color(255, 255, 255));
        lblPTexto.setForeground(new Color(0, 0, 0));
        this.Colocar("casa-silueta-negra-sin-puerta.png", lblCasita);

        //REGISTRO DE VENTA
        PanelDVenta.setBackground(new Color(255, 255, 255));
        lblR.setForeground(new Color(0, 0, 0));
        lblV.setForeground(new Color(0, 0, 0));
        this.Colocar("caja-registradora.png", lblRegistro);

        //PROVEEDOR
        PanelDProveedor.setBackground(new Color(255, 255, 255));
        lblPro.setForeground(new Color(0, 0, 0));
        this.Colocar("gestion-de-la-cadena-de-suministro.png", lblProveedor);
    }//GEN-LAST:event_PanelDProductosMouseClicked

    private void lblPrMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPrMouseClicked
        TCambiador.setSelectedIndex(3);
        PanelDProductos.setBackground(new Color(0, 0, 0));
        lblPr.setForeground(new Color(255, 255, 255));
        this.Colocar("productos-cosmeticos (1).png", lblProductos);

        //Lo demás
        //PRINCIPAL
        PanelDPrincipal.setBackground(new Color(255, 255, 255));
        lblPTexto.setForeground(new Color(0, 0, 0));
        this.Colocar("casa-silueta-negra-sin-puerta.png", lblCasita);

        //REGISTRO DE VENTA
        PanelDVenta.setBackground(new Color(255, 255, 255));
        lblR.setForeground(new Color(0, 0, 0));
        lblV.setForeground(new Color(0, 0, 0));
        this.Colocar("caja-registradora.png", lblRegistro);

        //PROVEEDOR
        PanelDProveedor.setBackground(new Color(255, 255, 255));
        lblPro.setForeground(new Color(0, 0, 0));
        this.Colocar("gestion-de-la-cadena-de-suministro.png", lblProveedor);
    }//GEN-LAST:event_lblPrMouseClicked

    private void lblProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProductosMouseClicked
        TCambiador.setSelectedIndex(3);
        PanelDProductos.setBackground(new Color(0, 0, 0));
        lblPr.setForeground(new Color(255, 255, 255));
        this.Colocar("productos-cosmeticos (1).png", lblProductos);

        //Lo demás
        //PRINCIPAL
        PanelDPrincipal.setBackground(new Color(255, 255, 255));
        lblPTexto.setForeground(new Color(0, 0, 0));
        this.Colocar("casa-silueta-negra-sin-puerta.png", lblCasita);

        //REGISTRO DE VENTA
        PanelDVenta.setBackground(new Color(255, 255, 255));
        lblR.setForeground(new Color(0, 0, 0));
        lblV.setForeground(new Color(0, 0, 0));
        this.Colocar("caja-registradora.png", lblRegistro);

        //PROVEEDOR
        PanelDProveedor.setBackground(new Color(255, 255, 255));
        lblPro.setForeground(new Color(0, 0, 0));
        this.Colocar("gestion-de-la-cadena-de-suministro.png", lblProveedor);
    }//GEN-LAST:event_lblProductosMouseClicked

    private void PanelSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelSesionMouseClicked
        System.exit(0);
    }//GEN-LAST:event_PanelSesionMouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void lblSalidaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSalidaMouseClicked
        System.exit(0);
    }//GEN-LAST:event_lblSalidaMouseClicked

    private void cbxProveedorItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxProveedorItemStateChanged
        String prov = (String) cbxProveedor.getSelectedItem();

        String consultaSql = "SELECT idProveedor FROM Proveedor WHERE pronombre = ?";
        try (PreparedStatement statement = con.prepareStatement(consultaSql)) {
            statement.setString(1, prov);
            ResultSet resultSet = statement.executeQuery();

            // Muestra el ID del producto en el JTextField
            if (resultSet.next()) {
                int idProveedor = resultSet.getInt("idProveedor");
                txtIDProveedor.setText(String.valueOf(idProveedor));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }//GEN-LAST:event_cbxProveedorItemStateChanged

    private void cbxProductoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxProductoItemStateChanged
        String prod = (String) cbxProducto.getSelectedItem();

        String consultaSql = "SELECT idProducto FROM Producto WHERE nombre = ?";
        String consultaprecio = "SELECT precio FROM Producto WHERE nombre = ?";

        try (PreparedStatement statement = con.prepareStatement(consultaSql)) {
            statement.setString(1, prod);
            ResultSet resultSet = statement.executeQuery();

            // Muestra el ID del producto en el JTextField
            if (resultSet.next()) {
                int idProducto = resultSet.getInt("idProducto");
                txtIDProducto.setText(String.valueOf(idProducto));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        try (PreparedStatement statement = con.prepareStatement(consultaprecio)) {
            statement.setString(1, prod);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Double precio = resultSet.getDouble("precio");
                txtPrecio.setText(String.valueOf(precio));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_cbxProductoItemStateChanged

    private void txtCantidadMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCantidadMousePressed

    }//GEN-LAST:event_txtCantidadMousePressed

    private void txtCantidadMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCantidadMouseReleased

    }//GEN-LAST:event_txtCantidadMouseReleased

    private void txtDescuentoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDescuentoMousePressed

    }//GEN-LAST:event_txtDescuentoMousePressed

    private void btnAgregarATablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarATablaActionPerformed
        String producto = (String) cbxProducto.getSelectedItem();
        String cantidad = txtCantidad.getText();
        String precio = txtPrecio.getText();
        String descuento = txtDescuento.getText();
        String subtotal = txtSubtotal.getText();
        String impuesto = txtImpuesto.getText();
        String total = txtTotal.getText();

        Object[] fila = {producto, cantidad, precio, descuento, subtotal, impuesto, total};
        modelito.addRow(fila);
    }//GEN-LAST:event_btnAgregarATablaActionPerformed

    private void btnQuitarDeTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQuitarDeTablaActionPerformed
        int com;

        com = tblDatos.getSelectedRow();
        if (com == -1) {
            JOptionPane.showMessageDialog(null, "Seleccionar el producto a eliminar");
        } else {
            modelito.removeRow(com);
        }

    }//GEN-LAST:event_btnQuitarDeTablaActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        try {
            Statement statement = con.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM DetalleVenta");

            ArrayList detallesVenta = new ArrayList();

            while (resultSet.next()) {
                int idVenta = resultSet.getInt("idVenta");
                String producto = resultSet.getString("producto");
                int cantidad = resultSet.getInt("cantidad");
                float descuento = resultSet.getFloat("descuento");
                float subtotal = resultSet.getFloat("subtotal");
                float impuesto = resultSet.getFloat("impuesto");
                float total = resultSet.getFloat("total");

                // Crear objeto DetalleVenta y agregarlo a la lista
                DetalleVenta detalleVenta = new DetalleVenta(idVenta, producto, cantidad, descuento, subtotal, impuesto, total);
                detallesVenta.add(detalleVenta);
            }
        }catch(SQLException ex){
            
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    /**
         * @param args the command line arguments
         */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(V_Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(V_Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(V_Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(V_Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new V_Sistema().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(V_Sistema.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PanelBanner;
    private javax.swing.JPanel PanelDPrincipal;
    private javax.swing.JPanel PanelDProductos;
    private javax.swing.JPanel PanelDProveedor;
    private javax.swing.JPanel PanelDVenta;
    private javax.swing.JPanel PanelDeVentas;
    private javax.swing.JPanel PanelDelMensaje;
    private javax.swing.JPanel PanelDown;
    private javax.swing.JPanel PanelFondo;
    private javax.swing.JPanel PanelFondoMenu;
    private javax.swing.JPanel PanelInicio;
    private javax.swing.JPanel PanelLateralDerecho;
    private javax.swing.JPanel PanelSesion;
    private javax.swing.JPanel PanelSubInicio;
    private javax.swing.JPanel PanelUp;
    private javax.swing.JTabbedPane TCambiador;
    private javax.swing.JButton btnAgregarATabla;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnQuitarDeTabla;
    private javax.swing.JComboBox<String> cbxProducto;
    private javax.swing.JComboBox<String> cbxProveedor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCasita;
    private javax.swing.JLabel lblLinea1;
    private javax.swing.JLabel lblLinea2;
    private javax.swing.JLabel lblLinea3;
    private javax.swing.JLabel lblLinea4;
    private javax.swing.JLabel lblLinea5;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblPTexto;
    private javax.swing.JLabel lblPastelito1;
    private javax.swing.JLabel lblPastelito10;
    private javax.swing.JLabel lblPastelito2;
    private javax.swing.JLabel lblPastelito3;
    private javax.swing.JLabel lblPastelito4;
    private javax.swing.JLabel lblPastelito5;
    private javax.swing.JLabel lblPastelito6;
    private javax.swing.JLabel lblPastelito7;
    private javax.swing.JLabel lblPastelito8;
    private javax.swing.JLabel lblPastelito9;
    private javax.swing.JLabel lblPr;
    private javax.swing.JLabel lblPro;
    private javax.swing.JLabel lblProductos;
    private javax.swing.JLabel lblProveedor;
    private javax.swing.JLabel lblR;
    private javax.swing.JLabel lblRegistro;
    private javax.swing.JLabel lblSalida;
    private javax.swing.JLabel lblTituloEntrada;
    private javax.swing.JLabel lblV;
    private javax.swing.JTable tblDatos;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtDescuento;
    private javax.swing.JTextField txtFactura;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtIDCompra;
    private javax.swing.JTextField txtIDProducto;
    private javax.swing.JTextField txtIDProveedor;
    private javax.swing.JTextField txtImpuesto;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtSubtotal;
    private javax.swing.JTextField txtTotal;
    private javax.swing.JTextField txtTotalFinal;
    // End of variables declaration//GEN-END:variables

}
