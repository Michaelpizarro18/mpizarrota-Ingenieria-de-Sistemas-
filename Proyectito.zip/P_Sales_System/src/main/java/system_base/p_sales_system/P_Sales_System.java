/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package system_base.p_sales_system;

/**
 *
 * @author Usuario
 */
public class P_Sales_System {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
