package Modelo_SalesSystem;

public class DetalleVenta {
    private int idVenta;
    private String producto;
    private int cantidad;
    private float descuento;
    private float subtotal;
    private float impuesto;
    private float total;

    // Constructor vacío
    public DetalleVenta() {
    }

    // Constructor con todos los atributos
    public DetalleVenta(int idVenta, String producto, int cantidad, float descuento, float subtotal, float impuesto, float total) {
        this.idVenta = idVenta;
        this.producto = producto;
        this.cantidad = cantidad;
        this.descuento = descuento;
        this.subtotal = subtotal;
        this.impuesto = impuesto;
        this.total = total;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public float getDescuento() {
        return descuento;
    }

    public void setDescuento(float descuento) {
        this.descuento = descuento;
    }

    public float getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(float subtotal) {
        this.subtotal = subtotal;
    }

    public float getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(float impuesto) {
        this.impuesto = impuesto;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    
    // Métodos getters y setters para todos los atributos
    // ...

    // Método toString para facilitar la depuración
    @Override
    public String toString() {
        return "DetalleVenta{" +
                "idVenta=" + idVenta +
                ", producto='" + producto + '\'' +
                ", cantidad=" + cantidad +
                ", descuento=" + descuento +
                ", subtotal=" + subtotal +
                ", impuesto=" + impuesto +
                ", total=" + total +
                '}';
    }
}
